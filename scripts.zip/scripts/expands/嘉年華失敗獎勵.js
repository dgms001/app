player.gainItem(2436130,1);
player.showTopScreenEffect("Map/Effect.img/SportsDay/EndMessage/Lose");