let event = npc.getEvent("測試副本4");
var sql = "SELECT id,Score  FROM zz_guild_sky ORDER BY Score DESC";
var resultList = player.customSqlResult(sql);
var result = resultList.get(0);
date = new Date();
let week = date.getDay();
let day = date.getDate();
let hour = date.getHours();
let minute = date.getMinutes();

var Icon = [
    Array("星星", "#fEtc/ChatEmoticon/expression/1/0#"),
    Array("彩虹", "#fEffect/ItemEff/1102877/effect/default/0#"),
    Array("猫咪", "#fUI/NameTag/190/w#"),
    Array("猫咪", "#fUI/NameTag/190/c#"),
    Array("猫咪", "#fUI/NameTag/190/e#"),
    Array("兔子", "#fEffect/CharacterEff/1112960/0/1#"),
    Array("星空", "#fUI/GuildMark/BackGround/00001013/16#"),
    Array("骷髅", "#fUI/GuildMark/Mark/Etc/00009000/15#"),
    Array("红心", "#fUI/GuildMark/Mark/Etc/00009001/1#"),
    Array("白脸", "#fUI/GuildMark/Mark/Etc/00009002/4#"),
    Array("皇冠", "#fUI/GuildMark/Mark/Etc/00009004/3#"),
    Array("红灯", "#fUI/GuildMark/Mark/Etc/00009020/1#"),
    Array("王冠", "#fUI/GuildMark/Mark/Etc/00009023/11#"),
    Array("水滴", "#fEffect/BasicEff/MainNotice/Gamsper/Notify/4#"),
    Array("红旗", "#fEffect/BasicEff/MainNotice/BlockBuster/Default/3#"),
    Array("红心", "#fEffect/CharacterEff/1112905/0/0#"),
    Array("云朵", "#fEffect/ItemEff/1102877/effect/default/1#"),
    Array("翅膀", "#fEffect/ItemEff/1102874/effect/ladder/0#"),
    Array("箭矢", "#fEffect/ItemEff/1112003/0/2#"),
    Array("黄鸭", "#fEffect/ItemEff/1004122/effect/default/8#"),
    Array("红点", "#fEffect/CharacterEff/1082588/0/0#"), //红点
    Array("蓝点", "#fEffect/CharacterEff/1082588/3/0#"),  //蓝点
    Array("黄星", "#fEffect/CharacterEff/1112924/0/0#"), //黄星
    Array("蓝星", "#fEffect/CharacterEff/1112925/0/0#"), //蓝星
    Array("红星", "#fEffect/CharacterEff/1112926/0/0#"), //红星
    Array("黄星星", "#fUI/UIPVP.img/MiniMapIcon/star#"),  //黄星星
    Array("星星", "#fEtc/ChatEmoticon/expression/1/0#"),
    Array("兔子", "#fEffect/CharacterEff/1112960/0/1#"),
    Array("星空", "#fUI/GuildMark/BackGround/00001013/16#"),
    Array("骷髅", "#fUI/GuildMark/Mark/Etc/00009000/15#"),
    Array("红心", "#fUI/GuildMark/Mark/Etc/00009001/1#"),
    Array("白脸", "#fUI/GuildMark/Mark/Etc/00009002/4#"),
    Array("皇冠", "#fUI/GuildMark/Mark/Etc/00009004/3#"),
    Array("红灯", "#fUI/GuildMark/Mark/Etc/00009020/1#"),
    Array("王冠", "#fUI/GuildMark/Mark/Etc/00009023/11#"),
    Array("水滴", "#fEffect/BasicEff/MainNotice/Gamsper/Notify/4#"),
    Array("红旗", "#fEffect/BasicEff/MainNotice/BlockBuster/Default/3#"),
    Array("红心", "#fEffect/CharacterEff/1112905/0/0#"),
    Array("云朵", "#fEffect/ItemEff/1102877/effect/default/1#"),
    Array("翅膀", "#fEffect/ItemEff/1102874/effect/ladder/0#"),
    Array("箭矢", "#fEffect/ItemEff/1112003/0/2#"),
    Array("黄鸭", "#fEffect/ItemEff/1004122/effect/default/8#"),
    Array("王冠", "#fUI/GuildMark/Mark/Etc/00009023/10#"),
    Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/2#"),
    Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/3#"),
    Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/4#"),
    Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/5#"),
    Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/6#"),
    Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/7#"),
    Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/8#"),
    Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/9#"),
    Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/10#"),
    Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/11#"),
    Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/12#"),
    Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/13#"),
    Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/14#"),
    Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/15#"),
    Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/16#"),
    Array("条件", "#fUI/UIWindow2.img/Quest/quest_info/summary_icon/startcondition#"),
    Array("信封", "#fUI/GuildMark/BackGround/00001003/5#"),
    Array("信封", "#fUI/GuildMark/BackGround/00001003/12#"),
    Array("钻石", "#fUI/NameTag/medal/556/w#"),
    Array("钻石", "#fUI/NameTag/medal/556/c#"),
    Array("钻石", "#fUI/NameTag/medal/556/e#"),
    Array("三角", "#fUI/piggyBarMinigame/crunch/5#"),
    Array("蓝点", "#fUI/piggyBarMinigame/crunch/1#"),
    Array("女神", "#fUI/RunnerGame/RunnerGameUI/Effect/ItemEffect_Protect1/3#"),
    Array("拇指", "#fUI/NameTag/medal/10/w#"),
    Array("拇指", "#fUI/NameTag/medal/10/c#"),
    Array("拇指", "#fUI/NameTag/medal/10/e#"),
    Array("成功", "#fUI/UIWindowJP/inputDirectionBattleTrigger/input/0/dear/7#"),
    Array("失败", "#fUI/UIWindowJP/inputDirectionBattleTrigger/input/0/fail/7#"),
    Array("星星", "#fUI/UIWindowGL/FeedbackSystem/Star#"),
    Array("蓝星", "#fEffect/CharacterEff/1003393/1/0#"),
    Array("花朵", "#fEffect/CharacterEff/1050334/2/0#"),
    Array("蓝星", "#fEffect/CharacterEff/1003393/0/0#"),
    Array("淡星", "#fEffect/CharacterEff/moveRandomSprayEff/eunwol_seal/effect/0/2#"),
    Array("花朵", "#fEffect/CharacterEff/1051294/1/0#"),
    Array("花朵", "#fEffect/CharacterEff/1051296/1/0#"),
    Array("金菇", "#fUI/NameTag/medal/74/w#"),
    Array("金菇", "#fUI/NameTag/medal/74/c#"),
    Array("金菇", "#fUI/NameTag/medal/74/e#"),
    Array("蛋糕", "#fUI/NameTag/medal/758/w#"),
    Array("蛋糕", "#fUI/NameTag/medal/758/c#"),
    Array("蛋糕", "#fUI/NameTag/medal/758/e#"),
    Array("胡子", "#fUI/NameTag/124/w#"),
    Array("胡子", "#fUI/NameTag/124/c#"),
    Array("胡子", "#fUI/NameTag/124/e#"),
    Array("帽子", "#fUI/NameTag/nick/312/w#"),
    Array("帽子", "#fUI/NameTag/nick/312/c#"),
    Array("帽子", "#fUI/NameTag/nick/312/e#"),
    Array("圣诞", "#fUI/NameTag/medal/728/w#"),
    Array("圣诞", "#fUI/NameTag/medal/728/c#"),
    Array("圣诞", "#fUI/NameTag/medal/728/e#"),
    Array("红钻", "#fUI/UIWindowPL/DuoEvent/Maximum/DuoInfo/icon/GoodF/0#"),
    Array("王冠", "#fUI/NameTag/medal/468/w#"),
    Array("王冠", "#fUI/NameTag/medal/468/c#"),
    Array("王冠", "#fUI/NameTag/medal/468/e#"),
    Array("确认", "#fUI/CashShop.img/CSCoupon/BtOK/normal/0#"),
    Array("幽灵", "#fEffect/ItemEff/1004738/effect/ladder/0#"),
    Array("幽灵", "#fEffect/ItemEff/1004738/effect/default/7#"),
    Array("幽灵", "#fEffect/ItemEff/1004738/effect/walk1/3#"),
    Array("幽灵", "#fEffect/ItemEff/1004738/effect/jump/0#"),
    Array("音符", "#fEffect/ItemEff/1112811/0/0#"),
    Array("红心", "#fEffect/CharacterEff/1112905/0/0#"),
    Array("幽灵", "#fEffect/ItemEff/1004738/effect/default/0#"),
    Array("幽灵", "#fEffect/ItemEff/1004738/effect/default/1#"),
    Array("幽灵", "#fEffect/ItemEff/1004738/effect/default/2#"),
    Array("幽灵", "#fEffect/ItemEff/1004738/effect/default/3#"),
    Array("金左指标", "#fUI/UIWindow/MonsterBook/arrowLeft/normal/0#"),
    Array("金右指标", "#fUI/UIWindow/MonsterBook/arrowRight/normal/0#"),
    Array("简单", "#fEffect/ItemEff/1102877/effect/default/0#")
];

txt = "\t" + Icon[17][1] + "#fs20##fc0xFF00caf2#搶奪城戰" + Icon[17][1] + "#r#n\r\n";
txt += "" + Icon[43][1] + Icon[44][1] + Icon[45][1] + Icon[46][1] + Icon[47][1] + Icon[48][1] + Icon[49][1] + Icon[50][1]
    + Icon[51][1] + Icon[52][1] + Icon[53][1] + Icon[54][1] + Icon[55][1] + Icon[56][1] + Icon[57][1] + Icon[43][1] + Icon[44][1]
    + Icon[45][1] + Icon[46][1] + Icon[47][1] + Icon[48][1] + Icon[49][1] + Icon[50][1] + Icon[51][1] + Icon[52][1] + Icon[53][1]
    + Icon[54][1] + Icon[55][1] + Icon[56][1] + Icon[57][1] + Icon[47][1] + Icon[44][1] + "\r\n";
//txt ="\r\n";
//txt+="王國爭奪戰\r\n";
if (result.get("id") != 0) {
    txt += "#fs13##b";
    txt += "當前城堡被 : #r" + getNAME(result.get("id")) + " #b 佔據\r\n";
} else {
    txt += "#r目前無人佔據,趕快佔領!#k\r\n";
}
// txt+="\r\n";
if (event != null) {
    txt += "當前最新戰況(重開介面刷新)\r\n";
    let guildIdss = event.getVariable("guildIdss");
    for (var i = 0; i < guildIdss.length; i++) {
        txt += "" + getNAME(guildIdss[i]) + " :  " + event.getVariable(guildIdss[i]) + " 分\r\n";
    }

}
txt += "#fs11##b";
txt += "說明:\r\n";
txt += "公會累積獲得10000分數成功佔據城堡\r\n";
txt += "同時全公會分數歸0\r\n";
txt += "倒計時結束前仍可篡位\r\n";
txt += "\r\n";
txt += "Q版人形怪物 : 30分\r\n";
txt += "Q版BOSS怪物 : 15分\r\n";
txt += "BOSS : 1000分\r\n";
txt += "得分方式 : 尾刀者公會獲得分數\r\n";
txt += "\t\t#r#L1#" + Icon[103][1] + "加入戰場#l\t#b#L2#城戰獎勵介紹#l\r\n\r\n";
txt += "" + Icon[43][1] + Icon[44][1] + Icon[45][1] + Icon[46][1] + Icon[47][1] + Icon[48][1] + Icon[49][1] + Icon[50][1]
    + Icon[51][1] + Icon[52][1] + Icon[53][1] + Icon[54][1] + Icon[55][1] + Icon[56][1] + Icon[57][1] + Icon[43][1] + Icon[44][1]
    + Icon[45][1] + Icon[46][1] + Icon[47][1] + Icon[48][1] + Icon[49][1] + Icon[50][1] + Icon[51][1] + Icon[52][1] + Icon[53][1]
    + Icon[54][1] + Icon[55][1] + Icon[56][1] + Icon[57][1] + Icon[47][1] + Icon[44][1] + "\r\n\r\n";
// txt+="由於系統問題 攻擊會判斷二次尾刀實際分數為\r\n";
// txt+="2分兩次 , 5分兩次 , 10分兩次\r\n";

if (event == null && player.isGm()) {
    txt += "#L0#GM開啟城戰#l\r\n";
}

//txt+="#L1#加入戰場#l\r\n";

if (player.isGm()) {


}

let sel = npc.askMenuS("" + txt, true);
if (sel == 0) {
    if (event == null) {
        let guildId = player.getGuildId();
        let guildName = player.getName();
        // if(player.isGm()){
        event = npc.makeEvent("測試副本4", true, [guildId, player]);
        // }

        if (event == null) {
            npc.say("現在世界BOSS還沒有開放，請稍後再試。");
        } else {
            npc.broadcastWeatherEffectNotice(6, "[城戰活動]開啟拉~請玩家至1分流,選擇萬能傳送-副本中心-搶奪城戰!!", 60000); //35[特效 1-???] 60000[1秒]
            //npc.broadcastPlayerNotice(13, "測試副本開始");
        }
    }
}

if (sel == 1) {
    if (player.getGuildId() == 0) {
        npc.say("#fs14##b你還沒有工會,無法進入");
    } else if (player.getChannel() != 1) {
        npc.sayS("活動只在1頻道進行。");
    } else if (event == null) {
        npc.say("#fs14##b當前沒有在進行");
    } else {
        let guildId = player.getGuildId();
        let guildName = player.getName();
        let guildIdss = event.getVariable("guildIdss");
        let members = event.getVariable("members");
        player.setEvent(event);
        members.push(player);
        if (event.getVariable(player.getGuildId()) == null) {
            guildIdss.push(player.getGuildId());//註冊公會
            event.setVariable(player.getGuildId(), 0);
            player.showSystemMessage("註冊公會成功");
        }
        player.changeMap(450001340, 0);
        player.showTopScreenEffect("Map/Effect.img/SportsDay/EndMessage/Start");
        player.showDeathCount();
    }
}

if (sel == 2) {
    getItemGuiId();
}


function getNAME(ID) { //轉成中文
    var sql = "select name from guilds where id = '" + ID + "' ";
    var result = player.customSqlResult(sql);
    if (result.size() > 0) {
        if (result.get(0) != null) {
            return result.get(0).get("name");
        }
    } else {
        return 0;
    }

}
function getItemGuiId() {
    var item = Array(
        Array(2430704, 1),
        Array(2433575, 10),
        Array(5062017, 10),
        Array(5062020, 10),
        Array(5062500, 10),
        Array(5062503, 3),
        Array(4032053, 1000)
    );
    var Icon = [
        Array("星星", "#fEtc/ChatEmoticon/expression/1/0#"),
        Array("彩虹", "#fEffect/ItemEff/1102877/effect/default/0#"),
        Array("猫咪", "#fUI/NameTag/190/w#"),
        Array("猫咪", "#fUI/NameTag/190/c#"),
        Array("猫咪", "#fUI/NameTag/190/e#"),
        Array("兔子", "#fEffect/CharacterEff/1112960/0/1#"),
        Array("星空", "#fUI/GuildMark/BackGround/00001013/16#"),
        Array("骷髅", "#fUI/GuildMark/Mark/Etc/00009000/15#"),
        Array("红心", "#fUI/GuildMark/Mark/Etc/00009001/1#"),
        Array("白脸", "#fUI/GuildMark/Mark/Etc/00009002/4#"),
        Array("皇冠", "#fUI/GuildMark/Mark/Etc/00009004/3#"),
        Array("红灯", "#fUI/GuildMark/Mark/Etc/00009020/1#"),
        Array("王冠", "#fUI/GuildMark/Mark/Etc/00009023/11#"),
        Array("水滴", "#fEffect/BasicEff/MainNotice/Gamsper/Notify/4#"),
        Array("红旗", "#fEffect/BasicEff/MainNotice/BlockBuster/Default/3#"),
        Array("红心", "#fEffect/CharacterEff/1112905/0/0#"),
        Array("云朵", "#fEffect/ItemEff/1102877/effect/default/1#"),
        Array("翅膀", "#fEffect/ItemEff/1102874/effect/ladder/0#"),
        Array("箭矢", "#fEffect/ItemEff/1112003/0/2#"),
        Array("黄鸭", "#fEffect/ItemEff/1004122/effect/default/8#"),
        Array("红点", "#fEffect/CharacterEff/1082588/0/0#"), //红点
        Array("蓝点", "#fEffect/CharacterEff/1082588/3/0#"),  //蓝点
        Array("黄星", "#fEffect/CharacterEff/1112924/0/0#"), //黄星
        Array("蓝星", "#fEffect/CharacterEff/1112925/0/0#"), //蓝星
        Array("红星", "#fEffect/CharacterEff/1112926/0/0#"), //红星
        Array("黄星星", "#fUI/UIPVP.img/MiniMapIcon/star#"),  //黄星星
        Array("星星", "#fEtc/ChatEmoticon/expression/1/0#"),
        Array("兔子", "#fEffect/CharacterEff/1112960/0/1#"),
        Array("星空", "#fUI/GuildMark/BackGround/00001013/16#"),
        Array("骷髅", "#fUI/GuildMark/Mark/Etc/00009000/15#"),
        Array("红心", "#fUI/GuildMark/Mark/Etc/00009001/1#"),
        Array("白脸", "#fUI/GuildMark/Mark/Etc/00009002/4#"),
        Array("皇冠", "#fUI/GuildMark/Mark/Etc/00009004/3#"),
        Array("红灯", "#fUI/GuildMark/Mark/Etc/00009020/1#"),
        Array("王冠", "#fUI/GuildMark/Mark/Etc/00009023/11#"),
        Array("水滴", "#fEffect/BasicEff/MainNotice/Gamsper/Notify/4#"),
        Array("红旗", "#fEffect/BasicEff/MainNotice/BlockBuster/Default/3#"),
        Array("红心", "#fEffect/CharacterEff/1112905/0/0#"),
        Array("云朵", "#fEffect/ItemEff/1102877/effect/default/1#"),
        Array("翅膀", "#fEffect/ItemEff/1102874/effect/ladder/0#"),
        Array("箭矢", "#fEffect/ItemEff/1112003/0/2#"),
        Array("黄鸭", "#fEffect/ItemEff/1004122/effect/default/8#"),
        Array("王冠", "#fUI/GuildMark/Mark/Etc/00009023/10#"),
        Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/2#"),
        Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/3#"),
        Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/4#"),
        Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/5#"),
        Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/6#"),
        Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/7#"),
        Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/8#"),
        Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/9#"),
        Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/10#"),
        Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/11#"),
        Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/12#"),
        Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/13#"),
        Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/14#"),
        Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/15#"),
        Array("灯组", "#fUI/GuildMark/Mark/Etc/00009020/16#"),
        Array("条件", "#fUI/UIWindow2.img/Quest/quest_info/summary_icon/startcondition#"),
        Array("信封", "#fUI/GuildMark/BackGround/00001003/5#"),
        Array("信封", "#fUI/GuildMark/BackGround/00001003/12#"),
        Array("钻石", "#fUI/NameTag/medal/556/w#"),
        Array("钻石", "#fUI/NameTag/medal/556/c#"),
        Array("钻石", "#fUI/NameTag/medal/556/e#"),
        Array("三角", "#fUI/piggyBarMinigame/crunch/5#"),
        Array("蓝点", "#fUI/piggyBarMinigame/crunch/1#"),
        Array("女神", "#fUI/RunnerGame/RunnerGameUI/Effect/ItemEffect_Protect1/3#"),
        Array("拇指", "#fUI/NameTag/medal/10/w#"),
        Array("拇指", "#fUI/NameTag/medal/10/c#"),
        Array("拇指", "#fUI/NameTag/medal/10/e#"),
        Array("成功", "#fUI/UIWindowJP/inputDirectionBattleTrigger/input/0/dear/7#"),
        Array("失败", "#fUI/UIWindowJP/inputDirectionBattleTrigger/input/0/fail/7#"),
        Array("星星", "#fUI/UIWindowGL/FeedbackSystem/Star#"),
        Array("蓝星", "#fEffect/CharacterEff/1003393/1/0#"),
        Array("花朵", "#fEffect/CharacterEff/1050334/2/0#"),
        Array("蓝星", "#fEffect/CharacterEff/1003393/0/0#"),
        Array("淡星", "#fEffect/CharacterEff/moveRandomSprayEff/eunwol_seal/effect/0/2#"),
        Array("花朵", "#fEffect/CharacterEff/1051294/1/0#"),
        Array("花朵", "#fEffect/CharacterEff/1051296/1/0#"),
        Array("金菇", "#fUI/NameTag/medal/74/w#"),
        Array("金菇", "#fUI/NameTag/medal/74/c#"),
        Array("金菇", "#fUI/NameTag/medal/74/e#"),
        Array("蛋糕", "#fUI/NameTag/medal/758/w#"),
        Array("蛋糕", "#fUI/NameTag/medal/758/c#"),
        Array("蛋糕", "#fUI/NameTag/medal/758/e#"),
        Array("胡子", "#fUI/NameTag/124/w#"),
        Array("胡子", "#fUI/NameTag/124/c#"),
        Array("胡子", "#fUI/NameTag/124/e#"),
        Array("帽子", "#fUI/NameTag/nick/312/w#"),
        Array("帽子", "#fUI/NameTag/nick/312/c#"),
        Array("帽子", "#fUI/NameTag/nick/312/e#"),
        Array("圣诞", "#fUI/NameTag/medal/728/w#"),
        Array("圣诞", "#fUI/NameTag/medal/728/c#"),
        Array("圣诞", "#fUI/NameTag/medal/728/e#"),
        Array("红钻", "#fUI/UIWindowPL/DuoEvent/Maximum/DuoInfo/icon/GoodF/0#"),
        Array("王冠", "#fUI/NameTag/medal/468/w#"),
        Array("王冠", "#fUI/NameTag/medal/468/c#"),
        Array("王冠", "#fUI/NameTag/medal/468/e#"),
        Array("确认", "#fUI/CashShop.img/CSCoupon/BtOK/normal/0#"),
        Array("幽灵", "#fEffect/ItemEff/1004738/effect/ladder/0#"),
        Array("幽灵", "#fEffect/ItemEff/1004738/effect/default/7#"),
        Array("幽灵", "#fEffect/ItemEff/1004738/effect/walk1/3#"),
        Array("幽灵", "#fEffect/ItemEff/1004738/effect/jump/0#"),
        Array("音符", "#fEffect/ItemEff/1112811/0/0#"),
        Array("红心", "#fEffect/CharacterEff/1112905/0/0#"),
        Array("幽灵", "#fEffect/ItemEff/1004738/effect/default/0#"),
        Array("幽灵", "#fEffect/ItemEff/1004738/effect/default/1#"),
        Array("幽灵", "#fEffect/ItemEff/1004738/effect/default/2#"),
        Array("幽灵", "#fEffect/ItemEff/1004738/effect/default/3#"),
        Array("金左指标", "#fUI/UIWindow/MonsterBook/arrowLeft/normal/0#"),
        Array("金右指标", "#fUI/UIWindow/MonsterBook/arrowRight/normal/0#"),
        Array("简单", "#fEffect/ItemEff/1102877/effect/default/0#")

    ];
    var text = "\t" + Icon[17][1] + "#fs20##fc0xFF00caf2#城戰獎勵" + Icon[17][1] + "#r#n\r\n";
    text += "" + Icon[43][1] + Icon[44][1] + Icon[45][1] + Icon[46][1] + Icon[47][1] + Icon[48][1] + Icon[49][1] + Icon[50][1]
        + Icon[51][1] + Icon[52][1] + Icon[53][1] + Icon[54][1] + Icon[55][1] + Icon[56][1] + Icon[57][1] + Icon[43][1] + Icon[44][1]
        + Icon[45][1] + Icon[46][1] + Icon[47][1] + Icon[48][1] + Icon[49][1] + Icon[50][1] + Icon[51][1] + Icon[52][1] + Icon[53][1]
        + Icon[54][1] + Icon[55][1] + Icon[56][1] + Icon[57][1] + Icon[47][1] + Icon[44][1] + "\r\n";
    text += "#fs11##b";

    text += "城戰獎勵規則如下:\r\n#n";
    text += "城戰佔領方工會成員獲得獎勵如下\r\n#n";
    for (let i = 1; i < item.length; i++) {
        text += "#v" + item[i][0] + "##z" + item[i][0] + "#*" + item[i][1] + "\r\n";
    }
    text += "非佔領方也會有50萬楓點獎勵 #v4032053##z4032053#*500\r\n#n";
    text += "值得注意的是 獎勵只有參與城戰至結束的玩家才會有獎勵";
    text += "佔領方結算頁面所有成員增加10工會貢獻點\r\n其他方所有結算成員獲得15工會貢獻點";
    text += "\r\n#r特殊福利:佔領方工會會長,在大廳有專屬NPC模型 隨著每一期變換而變換"
    text += "#fs11##r";
    npc.askMenuS(text);

}