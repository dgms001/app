//每日任務次數查詢
let cat1 = "#fItem/Pet/5000000.img/alert/0#";
let cat2 = "#fItem/Pet/5000000.img/fly/0#";
let cat3 = "#fItem/Pet/5000000.img/cry/0#";
let tu1 = "#fItem/Cash/0501.img/05010045/effect/stand1/1#"
let tu2 = "#fItem/Cash/0501.img/05010002/effect/default/7#"
let tu3 = "#fUI/NameTag/medal/758/w#"
let tu4 = "#fEffect/SetEff.img/245/effect/28#"
let tu5 = "#fUI/NameTag/medal/758/e#"
let tu6 = "#fUI/NameTag/medal/758/c#"
let fy = "#fUI/RunnerGame.img/RunnerGameUI/UI/Point/1#";
let fy1 = "#fUI/RunnerGame.img/RunnerGameUI/UI/Point/2#";
let dz = "#fUI/GuildMark/Mark/Etc/00009020/1#";
let dz1 = "#fEffect/CharacterEff/1003393/1/0#";
let star = "#fEffect/CharacterEff/1051294/1/1#"
let eff2 = "#fEffect/CharacterEff/1112925/0/0#";
var q1 = "#fEffect/CharacterEff/1050334/2/2#"; //紅色星星
var q2 = "#fMap/MapHelper.img/weather/starPlanet/2#"; //藍色星星
var q3 = "#fEffect/CharacterEff/1050334/1/2#"; //大藍色星星
var q4 = "#fMap/MapHelper.img/weather/2011Haloween/1#"; //小蝙蝠
var eff1 = "#fEffect/CharacterEff/1112924/0/0#";
var kkk1 = "#fMap/MapHelper.img/mark/Zakum#"; //扎昆
var kkk2 = "#fMap/MapHelper.img/mark/Hontale#"; //黑龍
var kkk3 = "#fMap/MapHelper.img/mark/Papulatus#"; //鬧鐘
var kkk4 = "#fMap/MapHelper.img/mark/PinkBean#"; //品克繽
var kkk5 = "#fMap/MapHelper.img/mark/YuYuanCN#"; //
var kkk6 = "#fMap/MapHelper.img/mark/Wedding#"; //
var kkk7 = "#fMap/MapHelper.img/mark/Vanleon#"; // 班雷昂
var a1 = "#fCharacter/Cape/01102934.img/swingP2/2/cape#";//蘑菇
var a2 = "#fUI/UIWindow2.img/MobGage/Mob/8880140#";//路西的
var a3 = "#fUI/UIWindow2.img/MobGage/Mob/8500001#";//鬧鐘
var a4 = "#fUI/UIWindow2.img/MobGage/Mob/8800002#";//"扎昆"
var a5 = "#fUI/UIWindow2.img/MobGage/Mob/8810018#";//黑龍
var a6 = "#fUI/UIWindow2.img/MobGage/Mob/8820001#";
//品科比
var a7 = "#fUI/UIWindow2.img/MobGage/Mob/8840007#";//班勒昂
var a8 = "#fUI/UIWindow2.img/MobGage/Mob/8870000#";//希臘
var a9 = "#fUI/UIWindow2.img/MobGage/Mob/8850011#";//西納斯
var a10 = "#fUI/UIWindow2.img/MobGage/Mob/5250007#";//愛妃你呀
var a11 = "#fEffect/CharacterEff/1051366/0/0#";
var a12 = "#fUI/UIWindow2.img/MobGage/Mob/9600086#";//鑽機
var a13 = "#fUI/UIWindow2.img/MobGage/Mob/9300306#";//自己的邪惡形象
var a14 = "#fUI/UIWindow2.img/MobGage/Mob/9390804#";//深海龍王
var a15 = "#fUI/UIWindow2.img/MobGage/Mob/9390600#";//貝勒德
var a16 = "#fUI/UIWindow2.img/MobGage/Mob/9800197#";//阿勒瑪
var a17 = "#fUI/UIWindow2.img/MobGage/Mob/8950002#";//四五
var a18 = "#fUI/UIWindow2.img/MobGage/Mob/8880002#";//暴君
var a19 = "#fUI/UIWindow2.img/MobGage/Mob/9309207#";//桃樂絲
var a20 = "#fUI/UIWindow2.img/MobGage/Mob/8880110#";//黛米安
var a21 = "#fUI/UIWindow2.img/MobGage/Mob/8880140#";//路西的
var a22 = "#fUI/UIWindow2.img/MobGage/Mob/8880343#";//威爾
var a23 = "#fUI/UIWindow2.img/MobGage/Mob/8920000#";
var a24 = "#fUI/UIWindow2.img/MobGage/Mob/9410271#";
var a25 = "#fMap/MapHelper.img/weather/starPlanet2/7#";
var ttt2 = "#fMap/MapHelper.img/mark/BattleSquare#"; //
var a26 = "#fUI/UIWindow2.img/MobGage/Mob/8860000#"; //阿卡伊勒
var a27 = "#fUI/UIWindow2.img/MobGage/Mob/9421581#"; //阿卡伊勒
var a28 = "#fUI/UIWindow2.img/MobGage/Mob/8880200#";//卡雄
var a29 = "#fUI/UIWindow2.img/MobGage/Mob/9600226#";//買個納斯
var a30 = "#fEffect/CharacterEff/1022223/6/0#" //跑马灯
var a31 = "#fEffect/CharacterEff/1022223/7/0#" //跑马灯
var a32 = "#fEffect/CharacterEff/1022223/8/0#" //跑马灯
var a38 = "#fItem/Pet/5000213.img/stand0/0#";//藍色惡魔
var f2 = "#fUI/CashShop/CSBeauty/hairColor/Enable/2#"
var f3 = "#fUI/CashShop/CSBeauty/hairColor/Enable/3#"
var f4 = "#fUI/CashShop/CSBeauty/hairColor/Enable/4#"
var f5 = "#fUI/CashShop/CSBeauty/hairColor/Enable/5#"
var c1 = "#fItem/Pet/5000935.img/stand0/0#";//
var c2 = "#fItem/Pet/5000709.img/stand0/0#";//
var d1 = "#fUI/UIPVP/MiniMapIcon/red#"
var d2 = "#fUI/UIPVP/MiniMapIcon/blue#"
var c12 = "#fUI/Basic/CheckBox1/1#";
var c11 = "#fUI/Basic/CheckBox1/0#";
var c13 = "#fUI/UIWindow7/pvp_main/button:log/normal/0#"
var jiazu = "#fUI/UIAchievement/achievement/pages/normalCategory/categoryTitle/sub/guild#"
var yangcheng = "#fUI/UIAchievement/achievement/pages/normalCategory/categoryTitle/main/growth#"
var renwu = "#fUI/UIAchievement/achievement/pages/normalCategory/categoryTitle/sub/quest#"
var zhandou = "#fUI/UIAchievement/achievement/pages/normalCategory/categoryTitle/main/battle#"
var ARC = "#fUI/UIWindow/ToolTip/WorldMap/ArcaneForce#"; //ARC需求
var AUT = "#fUI/UIWindow/ToolTip/WorldMap/AuthenticForce#"; //AUT需求
let title = "";
let clumn = "";
let data;
let sql;
//pqroll
let taskArray = [Array("" + f3 + "#rBOSS副本",
    Array(
        //BOSS名字 BOSSLOGNAME 最大次數 是否賬號記錄？(true/false) 開啟NPC名字
        Array("#d[普通]#k拉圖斯            ", "boss_papulatus_normal", 1, true, "拉圖斯進場"),
        Array("#r[困難]#k拉圖斯            ", "boss_papulatus_chaos", 1, true, "拉圖斯進場困難"),//3倍
        Array("#d[普通]#k炎魔              ", "boss_zakum", 1, true, "炎魔進場"),
        Array("#r[困難]#k炎魔              ", "boss_zakum_Chaos", 1, true, "炎魔進場困難"),//3倍
        Array("#d[普通]#k闇黑龍王          ", "boss_hontale", 1, true, "闇黑龍王進場"),
        Array("#r[困難]#k闇黑龍王          ", "boss_hontale_chaos", 1, true, "闇黑龍王進場困難"),
        Array("#d[普通]#k皮卡啾            ", "boss_pinkbeen", 1, true, "皮卡啾進場"),
        Array("#r[困難]#k皮卡啾            ", "boss_pinkbeen_chaos", 1, true, "皮卡啾進場困難"),//3倍
        Array("#d[普通]#k凡雷恩            ", "boss_vonleon", 1, true, "凡雷恩進場"),
        Array("#r[困難]#k凡雷恩            ", "boss_vonleon_hard", 1, true, "凡雷恩進場困難"),//3倍
        Array("#d[普通]#k阿卡伊農          ", "boss_akayrum_easy", 1, true, "阿卡伊農進場"),
        Array("#r[困難]#k阿卡伊農          ", "boss_akayrum", 1, true, "阿卡伊農進場困難"),//4倍
        Array("#d[普通]#k西格諾斯          ", "boss_shinas", 1, true, "西格諾斯進場"),
        Array("#r[困難]#k西格諾斯          ", "boss_shinas_HARD", 1, true, "西格諾斯進場困難"),//4倍
        Array("#d[普通]#k希拉              ", "boss_hillah", 1, true, "希拉進場"),
        Array("#r[困難]#k希拉              ", "boss_hillah_hard", 1, true, "希拉進場困難"),//4倍
        Array("#d[普通]#k比艾樂            ", "boss_pierre", 1, true, "比艾樂進場"),
        Array("#r[困難]#k比艾樂            ", "boss_pierre_chaos", 1, true, "比艾樂進場困難"),//5倍
        Array("#d[普通]#k斑斑              ", "BossBanban_NORMAL", 1, true, "斑斑進場"),
        Array("#r[困難]#k斑斑              ", "BossBanban_CHAOS", 1, true, "斑斑進場困難"),//5倍
        Array("#d[普通]#k血腥女王          ", "BossBloody_NORMAL", 1, true, "血腥皇后進場"),
        Array("#r[困難]#k血腥女王          ", "BossBloody_CHAOS", 1, true, "血腥皇后進場困難"),//5倍
        Array("#d[普通]#k貝倫              ", "BossBelen_NORMAL", 1, true, "貝倫進場"),
        Array("#r[困難]#k貝倫              ", "BossBelen_CHAOS", 1, true, "貝倫進場困難"),//5倍
        Array("#d[普通]#k森蘭丸            ", "boss_ranmaru", 1, true, "森蘭丸進場"),
        Array("#r[困難]#k森蘭丸            ", "boss_ranmaru_crazy", 1, true, "森蘭丸進場困難"),//5倍

        Array("#r[困難]#k濃姬              ", "BossPrincessNoPQ", 1, true, "濃姬進場"),
        Array("#r[困難]#k培羅德            ", "boss_beidler", 1, true, "培羅德進場"),

        Array("#d[普通]#k梅格耐斯          ", "boss_magnus", 1, true, "梅格耐斯進場"),
        Array("#r[困難]#k梅格耐斯          ", "boss_magnus_hard", 1, true, "梅格耐斯進場困難"),//10倍
        Array("#d[普通]#k史烏              ", "boss_siwu", 1, true, "史烏進場"),
        Array("#r[困難]#k史烏              ", "boss_siwu_chaos", 1, true, "史烏進場困難"),//10倍
        Array("#d[普通]#k戴米安            ", "boss_demian", 1, true, "戴米安進場"),
        Array("#r[困難]#k戴米安            ", "boss_demian_hard", 1, true, "戴米安進場困難"),//15倍
        Array("#d[普通]#k露希妲            ", "boss_lucid", 1, true, "露希妲進場"),
        Array("#r[困難]#k露希妲            ", "boss_lucid_hard", 1, true, "露希妲進場困難"),//15倍
        Array("#d[普通]#k威爾              ", "boss_will", 1, true, "威爾進場"),
        Array("#r[困難]#k威爾              ", "boss_will_hard", 1, true, "威爾進場困難"),//20倍



        Array("#d[普通]#k戴斯克            ", "boss_dusk", 1, true, "戴斯克進場"),
        Array("#r[困難]#k戴斯克            ", "boss_dusk_hard", 1, true, "戴斯克進場困難"),//30倍
        Array("#d[普通]#k真·希拉          ", "boss_jinhillah", 1, true, "真希拉進場"),
        Array("#r[困難]#k真·希拉          ", "boss_jinhillah_hard", 1, true, "真希拉進場困難"),//30倍
        Array("#d[普通]#k頓凱爾            ", "boss_dunkel", 1, true, "頓凱爾進場"),
        Array("#r[困難]#k頓凱爾            ", "boss_dunkel_hard", 1, true, "頓凱爾進場困難"),//30倍
        Array("#d[普通]#k黑魔法師          ", "boss_blackmage", 1, true, "黑魔法師進場"),
        Array("#r[困難]#k黑魔法師          ", "boss_blackmage_hard", 1, true, "黑魔法師進場困難"),//35倍
        Array("#d[普通]#k賽蓮              ", "boss_seren", 1, true, "賽蓮進場"),
        Array("#r[困難]#k賽蓮              ", "boss_seren_hard", 1, true, "賽蓮進場困難"),//35倍
        Array("#d[普通]#k天使水靈          ", "boss_slime", 1, true, "綠水靈進場"),
        Array("#r[困難]#k天使水靈          ", "boss_slime_chaos", 1, true, "綠水靈進場困難"),//40倍
        //Array("#d[普通]#k卡洛斯            ", "boss_kalos", 1, true, "卡洛斯進場"),
        //Array("#r[困難]#k卡洛斯            ", "boss_kalos_hard", 1, true, "卡洛斯進場困難")


    )
),
Array("#r" + f5 + "每日任務#l\r\n\r\n",
    Array(
        //BOSS名字 BOSSLOGNAME 最大次數 是否賬號記錄？(true/false) 開啟NPC名字
        Array("#r[每日]#k組隊任務#k                     ", "一條龍", 9, true, "onlymap", 410004008),
        Array("#r[每日]#k每日跑環#k                     ", "RINGQUSTION", 25, true, "每日跑環"),
        Array("#r[每日]#k每日尋寶#k                     ", "尋寶任務", 10, true, "每日尋寶")


    )
),
Array("#b" + f2 + "活動專屬#l",
    Array(
        Array("#d[小遊戲]#kOX問答#r[活動幣]            ", "OX已參與", 1, true, "onlymap", 910048000),
        Array("#d[小遊戲]#kBingo#r[活動幣]             ", "bingo已參與", 1, true, "onlymap", 922290000),
        Array("#d[小遊戲]#k旗幟爭奪#r[活動幣]          ", "雪原已參與", 1, true, "onlymap", 910048000),
        //BOSS名字 BOSSLOGNAME 最大次數 是否賬號記錄？(true/false) 開啟NPC名字
        //	Array("#婚禮一條龍組隊 ","婚禮一條龍組隊",1,true,"組隊中心"),
        //Array("#r結婚組隊獎勵 ","婚禮一條龍",1,true,"結婚系統"),
        //Array("#k第一次同行#k                   ", "party1", 1, true, "onlymap", 410004008),
        //Array("#k遺棄之塔#k                     ", "party2", 1, true, "onlymap", 410004008),
        //Array("#k龍騎士#k                       ", "party_dragon_rider", 1, true, "onlymap", 410004008),
        //Array("#k女王庭院	   ", "金幣副本獎勵", 10, true, "金幣副本入口"),
        //Array("#k次元入侵	   ", "DimensionInavde", 5, false, "每日專區")
        //Array("#k廢棄都市組隊  ","通關廢棄組隊",10,true,"組隊中心"),
        //Array("#k毒霧森林組隊   ","毒霧森林組隊任務",3,true,"組隊中心")


    )
),
Array("#b" + f4 + "日常副本#l",
    Array(
        //BOSS名字 BOSSLOGNAME 最大次數 是否賬號記錄？(true/false) 開啟NPC名字
        Array("#b世界BOSS#k[AUT/歐皇卷]               ", "武陵道場", 2, true, "世界boss"),
        Array("#b武陵道場#k[能源材料]                 ", "武陵道場", 3, true, "onlymap", 925020001),
        //點數兌換能源和材料 單獨強化 點數0-222隨機
        Array("#b起源之塔#k[塔戒/材料]                ", "aquaris_tower", 100, false, "onlymap", 992000000),
        //點數用來增加時間 BOSS關卡送袋子 50關掉落塔戒箱子 概率100%
        Array("#b次元入侵#k[方塊]                     ", "次元入侵", 3, true, "次元入侵進場"),
        //小怪掉落初始方塊 通關獲得捲軸升級材料
        Array("#b航海副本#k[心臟材料]                 ", "航海爭略", 3, true, "航海進場"),
        //通關獲得材料 兌換心臟 單獨強化
        Array("#b金字塔#k[機器人/材料]                ", "大蛇丸", 3, true, "大蛇丸進場"),
        //通關獲得材料 兌換機器人 單獨強化
        Array("#b飢餓的穆托#k[胸章材料]               ", "HungryMuto", 3, true, "球球島入場"),
        //通關獲得材料 兌換胸章 單獨強化
        Array("#b碎夢塔#k[拼圖/楓幣]                  ", "DreamBreak", 3, true, "碎夢塔"),
        //通關獲得材料 單獨強化
        Array("#b安哈林防禦#k[輪迴材料]               ", "EnheimDefence", 3, true, "安哈林防禦入場"),
        //通關獲得材料 單獨強化
        Array("#b靈魂拯救者#k[馬車道具材料]           ", "SpiritSavior", 3, true, "靈魂拯救者入場"),
        //通關獲得材料 單獨強化
        //Array("#b艾爾達光譜#k[符文材料]               ", "金幣副本獎勵", 3, true, "艾爾達光譜入場"),
        //通關獲得材料 單獨強化
        //Array("#b調和精靈#k[金幣,材料]                ", "金幣副本獎勵", 3, true, "aerkna"),
        //Array("#bPVP#k[金幣,材料]                ", "金幣副本獎勵", 3, true, "aerkna"),
        //Array("#b控制之神#k[金幣,材料]                ", "金幣副本獎勵", 3, true, "aerkna"),
    )
)];


var whileStage = true;
while (whileStage) {
    var selStr = "Welcome to the special trip              " + a38 + "\r\n";

    selStr += "" + a30 + "" + a30 + "" + a31 + "" + a31 + "" + a32 + "" + a32 + "" + a30 + "" + a30 + "" + a31 + "" + a31 + "" + a32 + "" + a32 + "" + a30 + "" + a30 + "" + a31 + "" + a31 + "" + a32 + "" + a32 + "" + a30 + "" + a30 + "" + a31 + "" + a31 + "" + a32 + "" + a32 + "\r\n";

    for (var i = 0; i < taskArray.length; i++) {
        selStr += "	  #L" + i + "#" + taskArray[i][0] + "#l";
    }

    let selected = npc.askMenuS(selStr);

    selStr = "";
    selStr += "點選目標可跳轉到任務介面！#r\r\n"
    for (var i = 0; i < taskArray[selected][1].length; i++) {
        var task = taskArray[selected][1][i];
        if (task[3]) {
            //賬號任務
            if (player.getEventValue(task[1]) >= task[2])
                selStr += "#r#L" + i + "#" + task[0] + "  " + c12 + "<" + player.getEventValue(task[1]) + "/" + task[2] + ">#d#l\r\n"
            else
                selStr += "#r#L" + i + "#" + task[0] + " #k " + c11 + "#d<" + player.getEventValue(task[1]) + "/" + task[2] + ">#d#l\r\n"
        } else {
            //角色任務
            if (player.getPQLog(task[1]) >= task[2])
                selStr += "#r#L" + i + "#" + task[0] + "  " + c12 + "<" + player.getPQLog(task[1]) + "/" + task[2] + ">#d#l\r\n"
            else
                selStr += "#r#L" + i + "#" + task[0] + " #k " + c11 + "#d<" + player.getPQLog(task[1]) + "/" + task[2] + ">#d#l\r\n"
        }
    }
    //selStr += "\r\n#r#L100861#點我返回上一頁#l"
    selected1 = npc.askMenuS(selStr);
    if (taskArray[selected][1][selected1][4] != "onlymap") {
        whileStage = false;
        player.runScript(taskArray[selected][1][selected1][4]);
    }
    if (taskArray[selected][1][selected1][4] == "onlymap") {
        whileStage = false;
        player.changeMap(taskArray[selected][1][selected1][5]);
    }
}
