player.gainItem(2436490,1);
player.showTopScreenEffect("Map/Effect.img/SportsDay/EndMessage/Win");