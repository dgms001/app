player.gainItem(2436383,1);
player.showTopScreenEffect("Map/Effect.img/SportsDay/EndMessage/Draw");