var ttt6 = "#fUI/UIWindow.img/PvP/Scroll/enabled/next2#";
var tz12 = "#fUI/GuildMark/Mark/Etc/00009020/8#"; //紅星

var ttt = "#fUI/UIWindow/Quest/icon2/7#"; //"+ttt+"//美化1
var ttt2 = "#fUI/UIWindow/Quest/icon6/7#"; ////美化2
var ttt3 = "#fUI/UIWindow/Quest/icon3/6#"; //"+ttt3+"//美化圓
var ttt4 = "#fUI/UIWindow/Quest/icon5/1#"; //"+ttt4+"//美化New
var ttt5 = "#fUI/UIWindow/Quest/icon0#"; ////美化!
var ttt7 = "#fUI/Basic/BtHide3/mouseOver/0#"; //"+ttt6+"//美化會員
var wi14 = "#fEffect/CharacterEff/1051294/1/4#"; //黃色星星
var ttt6 = "#fUI/UIWindowBT.img/WorldMap/BtQsearch/mouseOver/0#";
var kkk1 = "#fMap/MapHelper.img/mark/Zakum#"; //扎昆
var kkk2 = "#fMap/MapHelper.img/mark/Hontale#"; //黑龍
var kkk3 = "#fMap/MapHelper.img/mark/Papulatus#"; //鬧鐘
var kkk4 = "#fMap/MapHelper.img/mark/PinkBean#"; //品克繽
var kkk5 = "#fMap/MapHelper.img/mark/YuYuanCN#"; //
var kkk6 = "#fMap/MapHelper.img/mark/Wedding#"; //
var kkk7 = "#fMap/MapHelper.img/mark/VanLeon#"; // 班雷昂
var kkk8 = "#fMap/MapHelper.img/mark/Akairum#"; // 阿卡伊勒
var kkk9 = "#fMap/MapHelper.img/mark/GhostShip#"; //卡熊
var kkk10 = "#fMap/MapHelper.img/mark/Signus#"; //西拉斯
var kkk11 = "#fMap/MapHelper.img/mark/Hilla#"; //西拉
var kkk12 = "#fMap/MapHelper.img/mark/Ranmaru#"; //森蘭丸
var kkk13 = "#fMap/MapHelper.img/mark/Piere#"; //艾碧樂
var kkk14 = "#fMap/MapHelper.img/mark/BanBan#"; //斑斑
var kkk15 = "#fMap/MapHelper.img/mark/BloodyQueen#"; //血腥
var kkk16 = "#fMap/MapHelper.img/mark/Bellum#"; //貝倫
var kkk17 = "#fMap/MapHelper.img/mark/JP_Nohime#"; //農機
var kkk18 = "#fMap/MapHelper.img/mark/rootabyss#"; //斯烏
var kkk19 = "#fMap/MapHelper.img/mark/GiantVellud#"; //培羅德
var kkk20 = "#fMap/MapHelper.img/mark/Magnus#"; //暴君
var kkk21 = "#fMap/MapHelper.img/mark/KerningParty#"; //水靈
var kkk22 = "#fMap/MapHelper.img/mark/karotte#"; //卡洛斯
var kkk23 = "#fMap/MapHelper.img/mark/Cernium#"; //賽連
var a1 = "#fCharacter/Cape/01102934.img/swingP2/2/cape#";//蘑菇
var a2 = "#fUI/UIWindow2.img/MobGage/Mob/8880140#";//路西的
var a3 = "#fUI/UIWindow2.img/MobGage/Mob/8500001#";//鬧鐘
var a4 = "#fUI/UIWindow2.img/MobGage/Mob/8800002#";//"扎昆"
var a5 = "#fUI/UIWindow2.img/MobGage/Mob/8810018#";//黑龍
var a6 = "#fUI/UIWindow2.img/MobGage/Mob/8820001#";
//品科比
var a7 = "#fUI/UIWindow2.img/MobGage/Mob/8840007#";//班勒昂
var a8 = "#fUI/UIWindow2.img/MobGage/Mob/8870000#";//希臘
var a9 = "#fUI/UIWindow2.img/MobGage/Mob/8850011#";//西納斯
var a10 = "#fUI/UIWindow2.img/MobGage/Mob/5250007#";//愛妃你呀
var a11 = "#fEffect/CharacterEff/1051366/0/0#";
var a12 = "#fUI/UIWindow2.img/MobGage/Mob/9600086#";//鑽機
var a13 = "#fUI/UIWindow2.img/MobGage/Mob/9300306#";//自己的邪惡形象
var a14 = "#fUI/UIWindow2.img/MobGage/Mob/9390804#";//深海龍王
var a15 = "#fUI/UIWindow2.img/MobGage/Mob/9390600#";//貝勒德
var a16 = "#fUI/UIWindow2.img/MobGage/Mob/9800197#";//阿勒瑪
var a17 = "#fUI/UIWindow2.img/MobGage/Mob/8950002#";//四五
var a18 = "#fUI/UIWindow2.img/MobGage/Mob/8880002#";//暴君
var a19 = "#fUI/UIWindow2.img/MobGage/Mob/9309207#";//桃樂絲
var a20 = "#fUI/UIWindow2.img/MobGage/Mob/8880110#";//黛米安
var a21 = "#fUI/UIWindow2.img/MobGage/Mob/8880140#";//路西的
var a22 = "#fUI/UIWindow2.img/MobGage/Mob/8880343#";//威爾
var a23 = "#fUI/UIWindow2.img/MobGage/Mob/8920000#";
var a24 = "#fUI/UIWindow2.img/MobGage/Mob/9410271#";
var a25 = "#fMap/MapHelper.img/weather/starPlanet2/7#";
var ttt2 = "#fMap/MapHelper.img/mark/BattleSquare#"; //
var a26 = "#fUI/UIWindow2.img/MobGage/Mob/8860000#"; //阿卡伊勒
var a27 = "#fUI/UIWindow2.img/MobGage/Mob/9421581#"; //阿卡伊勒
var a31 = "#fUI/UIWindow2.img/MobGage/Mob/8644650#";//虛空之眼
var a32 = "#fUI/UIWindow2.img/MobGage/Mob/8644420#";//西拉
var a33 = "#fUI/UIWindow2.img/MobGage/Mob/8645009#";//頓開爾
var a34 = "#fUI/UIWindow2.img/MobGage/Mob/8880502#";//魔法師


var pqName = "";
var need = 0;

var mapList = Array(
	//     					名稱			 地圖ID     消耗金額    獲得物品 4個ID
	Array("" +kkk3 + "[#g#e入門#r]#k拉圖斯  ", 220080000, 0, 2000019, 4001713, 4001226,5062010,5062501,2613012),
	Array("" +kkk13 + "[#b#e進階#r]#k比艾樂  ", 105200000, 0, 2000019, 4001713, 4001227,5062010,5062501,1322203,1003797,2613062),
	Array("" +a17 + "[#r#e困難#r]#k斯烏    ", 350060300, 0, 2000019, 4001713, 4001230,5060048,4310156,1012632,1222109,1004423,2613068),
	
	Array("" +kkk1 + "[#g#e入門#r]#k炎魔    ", 211042300, 0, 2000019, 4001713, 4001226,5062010,5062501,2613012),
	Array("" +kkk14 + "[#b#e進階#r]#k斑斑    ", 105200000, 0, 2000019, 4001713, 4001227,5062010,5062501,1322203,1003797,2613062),
	Array("" +a20 + "[#r#e困難#r]#k戴米安  ", 105300303, 0, 2000019, 4001713, 4001230,5060048,4310156,1099015,1022278,1222109,1004423,2613068),
		
	Array("" +kkk2 + "[#g#e入門#r]#k黑龍    ", 240050400, 0, 2000019, 4001713, 4001226,5062010,5062501,2613012),	
	Array("" +kkk15 + "[#b#e進階#r]#k血腥女王", 105200000, 0, 2000019, 4001713, 4001227,5062010,5062501,1322203,1003797,2613062),
	Array("" +a21 + "[#r#e困難#r]#k露希妲  ", 450004000, 0, 2000019, 4001713, 4001229,5060048,4310249,1132308,1004808,1592020,2613068),
	
	Array("" +kkk4 + "[#g#e入門#r]#k皮卡啾  ", 270050000 ,0, 2000019, 4001713, 4001226,5062010,5062501,2613012),
	Array("" +kkk16 + "[#b#e進階#r]#k貝倫    ", 105200000, 0, 2000019, 4001713, 4001227,5062010,5062501,1322203,1003797,2613062),
	Array("" +a22 + "[#r#e困難#r]#k威爾   ", 450007240, 0, 2000019, 4001713, 4001229,5060048,4310249,1162083,2613068),
	
	
	Array("" +kkk7 + "[#g#e入門#r]#k凡雷恩  ", 211070000, 0, 2000019, 4001713, 4001226,5062010,5062501,2613012),
	Array("" +kkk12 + "[#b#e進階#r]#k森蘭丸  ", 807300100,0, 2000019, 4001713, 4001228,5062010,5062501,2613062),
    Array("" +a31 + "[#r#e困難#r]#k戴斯克  ", 450009301, 0, 2000019, 4001713, 5060048,4021019,1113306,2613068),	
	
	
	Array("" +kkk8 + "[#g#e入門#r]#k阿卡伊農", 272020110, 0, 2000019, 4001713, 4001226,5062010,5062501,2613048),	
	Array("" +kkk17 + "[#b#e進階#r]#k濃姬    ", 811000999,0, 2000019, 4001713, 4001228,5062010,5062501,1352109,2613062),
	Array("" +a32 + "[#r#e困難#r]#k真希拉  ", 450011990, 0, 2000019, 4001713, 5060048,4021019,1122430,2613068),
	
	Array("" +kkk11 + "[#g#e入門#r]#k希拉    ", 262030000, 0, 2000019, 4001713, 4001227,5062010,5062501,2613048),
    Array("" +kkk20 + "[#b#e進階#r]#k梅格耐斯", 401060000,0, 2000019, 4001713, 4001228,5062010,5062501,2613062),
	Array("" +a33 + "[#r#e困難#r]#k頓凱爾  ", 450012200, 0, 2000019, 4001713, 5060048,4021019,1032316,2613068),
	
	
	Array("" +kkk10 + "[#g#e入門#r]#k西格諾斯", 271040000, 0, 2000019, 4001713, 4001227,5062010,5062501,2613048),
    Array("" +kkk19 + "[#b#e進階#r]#k培羅德  ", 863000100,0, 2000019, 4001713, 4001228,5062010,5062501,1122267,1132245,1113073,1122264,2613062),
	Array("" +a34 + "[#r#e困難#r]#k黑魔法師", 450012500, 0, 2000019, 4001713, 5060048,4021019,1062289,1182285,2613068),
	
	
	Array("" +kkk9 + "[#g#e入門#r]#k卡雄    ", 221030900, 0, 2000019, 4001713, 4001227,5062010,5062501,2613048),
	Array("" +kkk23 + "[#r#e困難#r]#k賽蓮   ", 410000670, 0, 2000019, 4001713,5060048,4021019,1062289,1190555,2613068),
	Array("" +kkk21 + "[#r#e困難#r]#k天使水靈", 160000000, 0, 2000019, 4001713, 4001229,5060048,4310249,1672082,2613068),
	
	Array("" +kkk22 + "[#r#e史詩#r]#k卡洛斯", 410005005, 0, 2000019, 4001713, 5060048,4021019,1442284,1312212,2613068),
	
	

);

var selStr = "\r\n#e#d您好，史詩BOSS副本系列,更多請期待添加..#n#l#k\r\n\r\n";
for(var i = 0; i < mapList.length; i++) {
	selStr += "#L" + i + "##r#e#n" + mapList[i][0] + "#r#k#l#n";
	if(i % 2 == 1) {
		selStr += "";

	} else {
		selStr += "";
	}
}
selStr += "\r\n\r\n\r\n";
let selection = npc.askMenuA(selStr);
if(selection == 123) {
	var txt = "以下為boss次數\r\n";
	txt += "#rBOSS名稱#k           #b進入次數#k      #e剩餘次數#k\r\n";
	for(var i = 0; i < nameList.length; i++) {
		txt += "#r" + nameList[i][0] + "#k";
		// 填充名字空格
		for(var j = 0 ;j < 11-nameList[i][0].toString().length; j++) {
			txt += "  ";
		}

		txt += "#b" + player.getPQLog(nameList[i][1]) + "#k";

		txt += "\t\t\t#e";

		txt += nameList[i][2]-player.getPQLog(nameList[i][1]);
		txt += "#k\r\n";
	}
	npc.say(txt);

} else {
	//450004000
	
		
	
		var need = mapList[selection][2];
		var txt = "#fs21##e#r你選擇的副本為：\r\n\r\n" + mapList[selection][0]
		txt += "\r\n\r\n#b該副本會掉落:#r\r\n\r\n";
		for(var i = 3; i < mapList[selection].length; i++) {
			txt += "#v" + mapList[selection][i] + "##z" + mapList[selection][i] + "#\r\n";
		}
		let sel = npc.askYesNo(txt);
		if(sel == 1) {

			if(player.hasMesos(need)) { //判斷你背包金幣大於200000
				player.loseMesos(need); //扣去8888888
				player.changeMap(mapList[selection][1]); //傳送地圖
				player.showSystemMessage("你已經到達目的地,祝你遊戲愉快!");
			} else {
				npc.say("你沒有" + need + "金幣,我不能傳送你過去");
			}

		}
	
}