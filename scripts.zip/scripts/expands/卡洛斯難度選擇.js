if (player.getChannel() == 7 ||player.getChannel() == 5) {
          player.runScript("卡洛斯進場");//這是困難
        } else {
               player.runScript("卡洛斯普通進場");
            }